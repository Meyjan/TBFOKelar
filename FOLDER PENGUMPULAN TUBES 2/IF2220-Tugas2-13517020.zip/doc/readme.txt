------------------------Gunakanlah seperti kalkulator biasa-----------------------------                                                             
>> Contoh masukkan :                                                                                                                                 
Penjumlahan >> 2+3                                                                                                                                   
Pengurangan >> 2-3                                                                                                                                   
Perkalian >> 2*3                                                                                                                                     
Pembagian >> 2/3                                                                                                                                     
Perpangkatan >> 2^3                                                                                                                                  
Perkurungan >> 2*(3+2)

Jika ingin melanjutkan perhitungan lainnya, input Y atau y pada program. Jika ingin keluar dari program, tekan
N atau n pada program.  